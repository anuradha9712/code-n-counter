{
  "name": "bloggerApp",
  "version": "1.0.0",
  "description": "practice file",
  "main": "app.js",
  "scripts": {
    "test": "echo \"Error: no test specified\" && exit 1"
  },
  "author": "me",
  "license": "ISC",
  "dependencies": {
    "bcrypt": "^3.0.6",
    "body-parser": "^1.18.3",
    "ejs": "^2.6.1",
    "express": "^4.16.3",
    "jsonwebtoken": "^8.5.1",
    "mongoose": "^5.2.7"
  }
}
